from django.apps import AppConfig


class ProcesmanagementConfig(AppConfig):
    name = 'procesmanagement'
